# gitex-alexa

This is an Alexa sample skill in Python language, it runs on AWS lambda. It uses httplib2 for http request. And everything including the model is packaged into the zip file. Simply deploy the zip file to lambda is all you need.

for more: 

亚马逊Alexa与Echo产品设计分析 https://zhuanlan.zhihu.com/p/44097426
